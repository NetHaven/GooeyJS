export default class GradientShape {
    static CIRCLE = "circle";
    static ELLIPSE = "ellipse";
}
