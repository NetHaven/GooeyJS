export default class Event {
    constructor() {
        this.target = null;
        this.type = null;
    }
}
