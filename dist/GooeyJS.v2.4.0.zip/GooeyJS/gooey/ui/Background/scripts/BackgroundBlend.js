export default class BackgroundBlend {
    static DARKEN = "darken";
    static LIGHTEN = "lighten";
    static MULTIPLY = "multiply";
    static NORMAL = "normal";
    static OVERLAY = "overlay";
    static SCREEN = "screen";
}
