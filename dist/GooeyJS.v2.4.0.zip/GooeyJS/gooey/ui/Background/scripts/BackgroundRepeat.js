export default class BackgroundRepeat {
    static NO_REPEAT = "no-repeat";
    static REPEAT = "repeat";
    static REPEAT_X = "repeat-x";
    static REPEAT_Y = "repeat-y";
    static ROUND = "round";
    static SPACE = "space";
}
