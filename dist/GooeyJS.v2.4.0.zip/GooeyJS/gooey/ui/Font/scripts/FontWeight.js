export default class FontWeight {
    static NORMAL = 400;
    static BOLD = 700;
}
