export default class FormFactor {
    static DESKTOP = "DESKTOP";
    static MOBILE = "MOBILE";
    static TABLET = "TABLET";
}