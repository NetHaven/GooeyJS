export default class HorizontalAlign {
    static CENTER = "CENTER";
    static LEFT = "LEFT";
    static RIGHT = "RIGHT";
}
