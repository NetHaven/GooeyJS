export default class ToolbarButtonSize {
    static TINY = 'tiny';
    static SMALL = 'small';
    static MEDIUM = 'medium';
    static LARGE = 'large';
    static XLARGE = 'xlarge';
}
