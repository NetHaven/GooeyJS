export default class LayoutWrap {
    static NO_WRAP = "nowrap";
    static WRAP = "wrap";
    static WRAP_REVERSE = "wrap-reverse";
}
