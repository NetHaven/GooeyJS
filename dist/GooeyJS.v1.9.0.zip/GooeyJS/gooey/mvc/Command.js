export default class Command {
	execute() {
		console.log("Class failed to override Command.execute()");
	}	
}
