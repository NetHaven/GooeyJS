export default class GradientType {
    static CONIC = "conic";
    static LINEAR = "linear";
    static RADIAL = "radial";
}