 export default class LayoutDirection {
    static COLUMN = "column";
    static COLUMN_REVERSE = "column-reverse";
    static ROW = "row";
    static ROW_REVERSE = "row-reverse";
 }
