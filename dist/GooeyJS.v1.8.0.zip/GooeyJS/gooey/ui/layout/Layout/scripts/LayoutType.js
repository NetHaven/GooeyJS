export default class LayoutType {
    static BORDER = "BORDER";
    static CARD = "CARD";
    static GRID = "GRID";
    static BOX = "BOX";
    static FLOW = "FLOW";
}
