export default class Key {
    static ARROW_DOWN = "ArrowDown";
    static ARROW_LEFT = "ArrowLeft";
    static ARROW_RIGHT = "ArrowRight";
    static ARROW_UP = "ArrowUp";
    static ENTER = "Enter";
    static ESCAPE = "Escape";
    static SPACE = " ";
    static TAB = "Tab";
}