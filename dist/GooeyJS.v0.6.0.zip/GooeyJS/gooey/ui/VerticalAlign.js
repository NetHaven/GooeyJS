export default class VerticalAlign {
    static BOTTOM = "BOTTOM";
    static CENTER = "CENTER";
    static TOP = "TOP";
}
