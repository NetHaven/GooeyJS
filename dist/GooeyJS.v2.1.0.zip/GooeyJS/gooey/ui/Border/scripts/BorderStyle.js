export default class BorderStyle {
    static DASHED = "DASHED";
    static DOTTED = "DOTTED";
    static DOUBLE = "DOUBLE";
    static GROOVE = "GROOVE";
    static HIDDEN = "HIDDEN";
    static INSET = "INSET";
    static NONE = "NONE";
    static OUTSET = "OUTSET";
    static RIDGE = "RIDGE";
    static SOLID = "SOLID";
}
