export default class LayoutType {
    static BORDER = "BORDER";
    static BOX = "BOX";
    static CARD = "CARD";
    static FLOW = "FLOW";
    static GRID = "GRID";
    static HBOX = "HBOX";
    static VBOX = "VBOX";
}
