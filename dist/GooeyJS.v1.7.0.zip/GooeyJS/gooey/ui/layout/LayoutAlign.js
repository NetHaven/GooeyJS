export default class LayoutAlign {
    static BASELINE = "baseline";
    static CENTER = "center";
    static FLEX_END = "flex-end";
    static FLEX_START = "flex-start";
    static STRETCH = "stretch";
}
