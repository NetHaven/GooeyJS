export default class LayoutJustify {
    static CENTER = "center";
    static FLEX_END = "flex-end";
    static FLEX_START = "flex-start";
    static SPACE_AROUND = 'space-around';
    static SPACE_BETWEEN = "space-between";
    static SPACE_EVENLY = "space-evenly";
}
