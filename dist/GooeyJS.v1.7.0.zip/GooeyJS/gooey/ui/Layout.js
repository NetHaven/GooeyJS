export default class Layout {
    static BORDER = "BORDER";
    static CARD = "CARD";
    static GRID = "GRID";
    static HBOX = "HBOX";
    static FLOW = "FLOW";
    static VBOX = "VBOX";        
}
