export default class GradientSize {
    static CLOSEST_CORNER = "closest-corner";
    static CLOSEST_SIDE = "closest-side";
    static FARTHEST_CORNER = "farthest-corner";
    static FARTHEST_SIDE = "farthest-side";
}
