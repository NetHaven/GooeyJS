export default class BackgroundSize {
    static AUTO = "auto";
    static CONTAIN = "contain";
    static COVER = "cover";
}
