export default class BackgroundAttachment {
    static FIXED = "fixed";
    static LOCAL = "local";
    static SCROLL = "scroll";
}
