export default class LayoutAlign {
    static BASELINE = "baseline";
    static CENTER = "center";
    static END = "end";
    static START = "start";
    static STRETCH = "stretch";
}
