export default class LineWrap {
    static HARD = "hard";
    static OFF = "off";
    static SOFT = "soft";
}