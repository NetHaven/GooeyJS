import Key from '../../../../../io/Key.js';
import ListBox from '../../ListBox/scripts/ListBox.js';
import ComboBoxEvent from '../../../../../events/form/list/ComboBoxEvent.js';
import KeyboardEvent from '../../../../../events/KeyboardEvent.js';
import MouseEvent from '../../../../../events/MouseEvent.js';
import FormElementEvent from '../../../../../events/form/FormElementEvent.js';
import Template from '../../../../../util/Template.js';
import TextElementEvent from '../../../../../events/form/text/TextElementEvent.js';

export default class ComboBox extends ListBox {
    constructor() {
        super();

        // ListBox's constructor activated "ui-ListBox" (a <select multiple>) and moved
        // light-DOM <option> elements into it. Save those options, then remove the
        // ListBox template element so the ComboBox template is the only visible content.
        const listBoxSelect = this.listBox;
        const existingOptions = Array.from(listBoxSelect.options);
        listBoxSelect.remove();

        Template.activate("ui-ComboBox", this.shadowRoot);

        // Create the combo box structure
        this.listBox = this.shadowRoot.querySelector("select.combobox-list");
        this._container = this.shadowRoot.querySelector('div.combobox-container');
        this._textInput = this.shadowRoot.querySelector('input.combobox-input');
        this._dropdownButton = this.shadowRoot.querySelector('button.combobox-button');
        this._dropdownContainer = this.shadowRoot.querySelector('div.combobox-dropdown');
        this._dropdownContainer.style.display = 'none';

        // Move options from the old ListBox select to the ComboBox's internal select
        existingOptions.forEach(option => {
            this.listBox.appendChild(option);
        });

        // Update formElement reference for FormElement functionality
        this.formElement = this._textInput;

        // Note: ARIA role will be set in connectedCallback (Custom Elements spec)

        // Generate unique ID for the listbox
        const listboxId = `combobox-listbox-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        this._dropdownContainer.id = listboxId;
        this._dropdownContainer.setAttribute('role', 'listbox');

        // Link input to listbox
        this._textInput.setAttribute('aria-haspopup', 'listbox');
        this._textInput.setAttribute('aria-expanded', 'false');
        this._textInput.setAttribute('aria-controls', listboxId);
        this._textInput.setAttribute('aria-owns', listboxId);
        this._textInput.setAttribute('aria-autocomplete', this.hasAttribute('editable') ? 'list' : 'none');

        // Set up event handlers
        this._setupEventHandlers();
        
        // Initialize dropdown state
        this._isDropdownOpen = false;
        this._filteredOptions = [];
        
        // Track if we're in editable mode
        this._editable = this.hasAttribute('editable');
        
        // Set initial value if specified
        if (this.hasAttribute('value')) {
            this.value = this.getAttribute('value');
        }
        
        // Set initial text if specified
        if (this.hasAttribute('text')) {
            this.text = this.getAttribute('text');
        }

        // Set pattern if specified
        if (this.hasAttribute('pattern')) {
            this._textInput.setAttribute('pattern', this.getAttribute('pattern'));
        }

        // Add valid events
        this.addValidEvent(FormElementEvent.FOCUS);
        this.addValidEvent(FormElementEvent.BLUR);
        this.addValidEvent(ComboBoxEvent.DROPDOWN_OPEN);
        this.addValidEvent(ComboBoxEvent.DROPDOWN_CLOSE);
        this.addValidEvent(ComboBoxEvent.CHANGE);
    }
    
    /**
     * Set up event handlers for combo box functionality
     */
    _setupEventHandlers() {
        // Dropdown button click
        this._dropdownButton.addEventListener(MouseEvent.CLICK, (e) => {
            e.preventDefault();
            e.stopPropagation();
            this._toggleDropdown();
        });
        
        // Text input events
        this._textInput.addEventListener(TextElementEvent.INPUT, (e) => {
            if (this._editable) {
                this._filterOptions(e.target.value);
                this._openDropdown();
            }
        });
        
        this._textInput.addEventListener(KeyboardEvent.KEY_DOWN, (e) => {
            this._handleKeydown(e);
        });
        
        this._textInput.addEventListener(MouseEvent.CLICK, () => {
            if (!this._editable) {
                this._toggleDropdown();
            }
        });
        
        // ListBox selection change
        this.listBox.addEventListener(TextElementEvent.CHANGE, () => {
            this._handleSelectionChange();
        });
        
        this.listBox.addEventListener(MouseEvent.CLICK, () => {
            // Close dropdown when option is clicked
            this._closeDropdown();
        });

        // Close dropdown when clicking outside
        this._boundDocumentClickHandler = (e) => {
            if (!this.contains(e.target)) {
                this._closeDropdown();
            }
        };
        document.addEventListener(MouseEvent.CLICK, this._boundDocumentClickHandler);

        // Handle focus/blur for proper form behavior
        this._textInput.addEventListener(FormElementEvent.FOCUS, (e) => {
            this.classList.add('focused');
            
            // Dispatch custom focus event
            this.fireEvent(FormElementEvent.FOCUS, { 
                value: this.value,
                text: this.text,
                originalEvent: e
            });
        });
        
        this._textInput.addEventListener(FormElementEvent.BLUR, (e) => {
            this.classList.remove('focused');
            
            // Dispatch custom blur event
            this.fireEvent(FormElementEvent.BLUR, { 
                value: this.value,
                text: this.text,
                originalEvent: e
            });
            
            // Delay closing to allow for click on dropdown
            setTimeout(() => {
                if (!this._dropdownContainer.contains(document.activeElement)) {
                    this._closeDropdown();
                }
            }, 150);
        });
    }
    
    /**
     * Handle keyboard navigation
     */
    _handleKeydown(e) {
        switch (e.key) {
            case Key.ARROW_DOWN:
                e.preventDefault();
                if (!this._isDropdownOpen) {
                    this._openDropdown();
                } else {
                    this._selectNextOption();
                }
                break;
                
            case Key.ARROW_UP:
                e.preventDefault();
                if (this._isDropdownOpen) {
                    this._selectPreviousOption();
                }
                break;
                
            case Key.ENTER:
                e.preventDefault();
                if (this._isDropdownOpen) {
                    this._selectCurrentOption();
                    this._closeDropdown();
                } else {
                    this._openDropdown();
                }
                break;
                
            case Key.ESCAPE:
                e.preventDefault();
                this._closeDropdown();
                break;
                
            case Key.TAB:
                this._closeDropdown();
                break;
        }
    }
    
    /**
     * Filter options based on input text
     */
    _filterOptions(filterText) {
        if (!this._editable) return;
        
        const filter = filterText.toLowerCase();
        this._filteredOptions = [];
        
        for (let i = 0; i < this.listBox.options.length; i++) {
            const option = this.listBox.options[i];
            const matches = option.textContent.toLowerCase().includes(filter);
            option.style.display = matches ? '' : 'none';
            
            if (matches) {
                this._filteredOptions.push(i);
            }
        }
    }
    
    /**
     * Handle selection change from listBox
     */
    _handleSelectionChange() {
        if (this.listBox.selectedIndex >= 0) {
            const selectedOption = this.listBox.options[this.listBox.selectedIndex];
            this._textInput.value = selectedOption.textContent;

            // Fire change event
            this.fireEvent(ComboBoxEvent.CHANGE, {
                value: this.value,
                text: selectedOption.textContent,
                selectedIndex: this.listBox.selectedIndex
            });
        }
    }
    
    /**
     * Navigation methods
     */
    _selectNextOption() {
        const visibleOptions = this._getVisibleOptions();
        if (visibleOptions.length === 0) return;
        
        let nextIndex = 0;
        if (this.listBox.selectedIndex >= 0) {
            const currentPos = visibleOptions.indexOf(this.listBox.selectedIndex);
            nextIndex = (currentPos + 1) % visibleOptions.length;
        }
        
        this.listBox.selectedIndex = visibleOptions[nextIndex];
        this._scrollToSelected();
    }
    
    _selectPreviousOption() {
        const visibleOptions = this._getVisibleOptions();
        if (visibleOptions.length === 0) return;
        
        let prevIndex = visibleOptions.length - 1;
        if (this.listBox.selectedIndex >= 0) {
            const currentPos = visibleOptions.indexOf(this.listBox.selectedIndex);
            prevIndex = currentPos > 0 ? currentPos - 1 : visibleOptions.length - 1;
        }
        
        this.listBox.selectedIndex = visibleOptions[prevIndex];
        this._scrollToSelected();
    }
    
    _selectCurrentOption() {
        if (this.listBox.selectedIndex >= 0) {
            this._handleSelectionChange();
        }
    }
    
    _getVisibleOptions() {
        const visible = [];
        for (let i = 0; i < this.listBox.options.length; i++) {
            if (this.listBox.options[i].style.display !== 'none') {
                visible.push(i);
            }
        }
        return visible;
    }
    
    _scrollToSelected() {
        if (this.listBox.selectedIndex >= 0) {
            const selectedOption = this.listBox.options[this.listBox.selectedIndex];
            selectedOption.scrollIntoView({ block: 'nearest' });
        }
    }
    
    /**
     * Dropdown control methods
     */
    _openDropdown() {
        if (this._isDropdownOpen) return;

        this._isDropdownOpen = true;
        this._dropdownContainer.style.display = 'block';
        this._dropdownButton.innerHTML = '▲';
        this.classList.add('dropdown-open');

        // ARIA: Update expanded state
        this._textInput.setAttribute('aria-expanded', 'true');

        // Reset filter if in editable mode
        if (this._editable) {
            this._filterOptions(this._textInput.value);
        }

        // Set dropdown width to match input width
        const inputWidth = this._textInput.offsetWidth + this._dropdownButton.offsetWidth;
        this._dropdownContainer.style.width = `${inputWidth}px`;

        // Dispatch event
        this.fireEvent(ComboBoxEvent.DROPDOWN_OPEN);
    }

    _closeDropdown() {
        if (!this._isDropdownOpen) return;

        this._isDropdownOpen = false;
        this._dropdownContainer.style.display = 'none';
        this._dropdownButton.innerHTML = '▼';
        this.classList.remove('dropdown-open');

        // ARIA: Update expanded state
        this._textInput.setAttribute('aria-expanded', 'false');

        // Show all options when closed
        for (let i = 0; i < this.listBox.options.length; i++) {
            this.listBox.options[i].style.display = '';
        }

        // Dispatch event
        this.fireEvent(ComboBoxEvent.DROPDOWN_CLOSE);
    }
    
    _toggleDropdown() {
        if (this._isDropdownOpen) {
            this._closeDropdown();
        } else {
            this._openDropdown();
        }
    }
    
    /**
     * Properties and getters/setters
     */
    get editable() {
        return this._editable;
    }
    
    set editable(val) {
        this._editable = Boolean(val);
        this._textInput.readOnly = !this._editable;
        
        if (val) {
            this.setAttribute('editable', '');
        } else {
            this.removeAttribute('editable');
        }
    }
    
    get text() {
        return this._textInput.value;
    }

    set text(val) {
        this._textInput.value = val || '';
        this.setAttribute('text', val || '');
    }

    get pattern() {
        return this.getAttribute('pattern');
    }

    set pattern(val) {
        if (val) {
            this.setAttribute('pattern', val);
            this._textInput.setAttribute('pattern', val);
        }
    }

    // Override value to work with the text input
    get value() {
        // If we have a selected option, return its value, otherwise return the text
        if (this.listBox.selectedIndex >= 0) {
            return this.listBox.value;
        }
        return this._textInput.value;
    }
    
    set value(val) {
        // Try to select the option with this value
        this.listBox.value = val;
        
        // If successful, update text input with the option text
        if (this.listBox.selectedIndex >= 0) {
            this._textInput.value = this.listBox.options[this.listBox.selectedIndex].textContent;
        } else {
            // Otherwise, just set the text input value
            this._textInput.value = val || '';
        }
        
        this.setAttribute('value', val || '');
    }
    
    // Override disabled to affect both input and button
    get disabled() {
        return this._textInput.disabled;
    }
    
    set disabled(val) {
        super.disabled = val;
        this._textInput.disabled = val;
        this._dropdownButton.disabled = val;
        
        if (val) {
            this._closeDropdown();
        }
    }
    
    // Override focus to focus the text input
    focus() {
        this._textInput.focus();
    }
    
    // Add method to clear the text input
    clearText() {
        this._textInput.value = '';
        this.listBox.selectedIndex = -1;
    }
    
    // Override addOption to potentially select the new option
    addOption(text, value = null, selected = false) {
        super.addOption(text, value, selected);
        
        if (selected) {
            this._textInput.value = text;
        }
    }

    connectedCallback() {
        // ARIA: Set combobox role (must be done here, not in constructor per Custom Elements spec)
        if (!this.hasAttribute('role')) {
            this.setAttribute('role', 'combobox');
        }

        // Call parent setup if exists
        super.connectedCallback?.();
    }

    disconnectedCallback() {
        // Remove document-level listener to prevent leaks
        document.removeEventListener(MouseEvent.CLICK, this._boundDocumentClickHandler);

        // Call parent cleanup (model unbinding, etc.)
        super.disconnectedCallback?.();
    }

    attributeChangedCallback(name, oldValue, newValue) {
        // Guard against infinite recursion: setters call setAttribute which re-triggers this callback
        if (oldValue === newValue) return;

        super.attributeChangedCallback(name, oldValue, newValue);

        switch (name) {
            case 'editable':
                this.editable = newValue !== null;
                break;
            case 'pattern':
                this.pattern = newValue;
                break;
            case 'text':
                this.text = newValue;
                break;
            case 'value':
                this.value = newValue;
                break;
        }
    }
}