import Window from '../../Window/scripts/Window.js';

export default class FloatingPane extends Window {
    constructor() {
        super();
    }
}