export default class LayoutJustify {
    static CENTER = "center";
    static END = "end";
    static START = "start";
    static SPACE_AROUND = 'space-around';
    static SPACE_BETWEEN = "space-between";
    static SPACE_EVENLY = "space-evenly";
    static STRETCH = "stretch";
}
