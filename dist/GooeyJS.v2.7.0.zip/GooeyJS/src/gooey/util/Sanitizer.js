/**
 * Shared HTML sanitization utility with configurable profiles.
 *
 * Provides DOM-based allowlist sanitization to prevent XSS attacks.
 * All components that inject user-provided HTML should use this utility
 * rather than implementing inline sanitizers.
 *
 * @module Sanitizer
 */

/**
 * Default tag allowlist (union of all component needs).
 * @type {Set<string>}
 */
const ALLOWED_TAGS = new Set([
    'b', 'i', 'u', 'em', 'strong', 'span', 'p', 'br',
    'ul', 'ol', 'li', 'a', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'blockquote', 'code', 'pre', 'table', 'thead', 'tbody', 'tr', 'td', 'th',
    'div', 'hr', 'small', 'sub', 'sup', 'mark', 'del', 'ins'
]);

/**
 * Safe attributes -- NO 'style' by default (FIX-11).
 * Components that need style support must opt in via allowStyle option.
 * @type {Set<string>}
 */
const ALLOWED_ATTRS = new Set([
    'class', 'id', 'href', 'target', 'title',
    'colspan', 'rowspan', 'align', 'valign'
]);

/**
 * Safe CSS properties for filtered style attribute when allowStyle is true.
 * @type {Set<string>}
 */
const ALLOWED_STYLE_PROPERTIES = new Set([
    'color', 'background-color', 'font-weight', 'font-style',
    'text-decoration', 'text-align', 'margin', 'padding',
    'border', 'display', 'width', 'height', 'font-size',
    'font-family', 'line-height', 'vertical-align', 'margin-left'
]);

/**
 * URL attributes that may contain dangerous schemes.
 * @type {Set<string>}
 */
const URL_ATTRIBUTES = new Set([
    'href', 'src', 'action', 'formaction', 'data', 'codebase'
]);

/**
 * Allowed URL protocols (allowlist approach).
 * Only these protocols are permitted in URL attributes.
 * @type {Set<string>}
 */
const ALLOWED_PROTOCOLS = new Set(['http:', 'https:', 'mailto:', 'tel:']);

/**
 * Control character regex for stripping from URLs before validation.
 * @type {RegExp}
 */
const URL_CONTROL_CHARS_RE = /[\x00-\x1f\x7f]/g;

/**
 * Dangerous CSS value patterns that can execute scripts or load external resources.
 * @type {RegExp}
 */
const DANGEROUS_CSS_VALUE_RE = /url\s*\(|expression\s*\(|@import|(?:^|[;\s])-moz-binding|behavior\s*:/i;

/**
 * Control characters in CSS values that may be used for obfuscation.
 * @type {RegExp}
 */
const CSS_CONTROL_CHARS_RE = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/;

export default class Sanitizer {
    /**
     * Sanitize HTML string using DOM-based allowlist.
     *
     * @param {string} html - Raw HTML
     * @param {Object} [options] - Configuration
     * @param {Set} [options.allowedTags] - Override tag allowlist
     * @param {Set} [options.allowedAttrs] - Override attribute allowlist
     * @param {boolean} [options.allowStyle] - Allow filtered style attribute (default false)
     * @returns {string} Sanitized HTML
     */
    static sanitize(html, options = {}) {
        if (!html) return '';

        const tags = options.allowedTags || ALLOWED_TAGS;
        const attrs = options.allowedAttrs || ALLOWED_ATTRS;
        const allowStyle = options.allowStyle || false;

        const temp = document.createElement('div');
        temp.innerHTML = html;

        const walker = document.createTreeWalker(temp, NodeFilter.SHOW_ELEMENT);
        const toRemove = [];

        let node = walker.nextNode();
        while (node) {
            const tagName = node.tagName.toLowerCase();
            if (!tags.has(tagName)) {
                toRemove.push(node);
            } else {
                Sanitizer._cleanAttributes(node, attrs, allowStyle);
            }
            node = walker.nextNode();
        }

        // Replace disallowed elements with their text content
        for (const el of toRemove) {
            const text = document.createTextNode(el.textContent);
            if (el.parentNode) {
                el.parentNode.replaceChild(text, el);
            }
        }

        return temp.innerHTML;
    }

    /**
     * Clean attributes on an element, removing dangerous ones.
     *
     * @param {Element} el - Element to clean
     * @param {Set} allowedAttrs - Allowed attribute names
     * @param {boolean} allowStyle - Whether to permit filtered style
     * @private
     */
    static _cleanAttributes(el, allowedAttrs, allowStyle) {
        const attrsToRemove = [];

        for (const attr of Array.from(el.attributes)) {
            const name = attr.name.toLowerCase();
            const value = attr.value;

            // Strip on* event handler attributes
            if (name.startsWith('on')) {
                attrsToRemove.push(attr.name);
                continue;
            }

            // Handle style attribute
            if (name === 'style') {
                if (allowStyle) {
                    const filtered = Sanitizer._filterStyle(value);
                    if (filtered) {
                        el.setAttribute('style', filtered);
                    } else {
                        attrsToRemove.push(attr.name);
                    }
                } else {
                    attrsToRemove.push(attr.name);
                }
                continue;
            }

            // Check URL attributes against protocol allowlist
            if (URL_ATTRIBUTES.has(name)) {
                if (!Sanitizer._isAllowedURL(value)) {
                    attrsToRemove.push(attr.name);
                    continue;
                }
            }

            // Remove attributes not in allowlist
            if (!allowedAttrs.has(name)) {
                attrsToRemove.push(attr.name);
            }
        }

        for (const attrName of attrsToRemove) {
            el.removeAttribute(attrName);
        }
    }

    /**
     * Filter a CSS style string to only allowed properties.
     *
     * @param {string} styleValue - Raw style attribute value
     * @returns {string} Filtered style string, or empty string
     */
    static _filterStyle(styleValue) {
        if (!styleValue) return '';

        const parts = styleValue.split(';').filter(Boolean);
        const allowed = [];

        for (const part of parts) {
            const colonIdx = part.indexOf(':');
            if (colonIdx === -1) continue;

            const prop = part.slice(0, colonIdx).trim().toLowerCase();
            const value = part.slice(colonIdx + 1).trim();

            if (ALLOWED_STYLE_PROPERTIES.has(prop) && value) {
                // Reject dangerous CSS value patterns
                if (DANGEROUS_CSS_VALUE_RE.test(value)) continue;
                if (CSS_CONTROL_CHARS_RE.test(value)) continue;
                allowed.push(`${prop}: ${value}`);
            }
        }

        return allowed.length > 0 ? allowed.join('; ') : '';
    }

    /**
     * Check whether a URL value uses an allowed protocol.
     * Strips control characters, then parses with the URL constructor.
     * Only http:, https:, mailto:, and tel: protocols are permitted.
     * Relative URLs (no explicit protocol) are allowed.
     *
     * @param {string} value - URL attribute value to check
     * @returns {boolean} true if URL is safe
     * @private
     */
    static _isAllowedURL(value) {
        if (!value) return true;

        const normalized = value.replace(URL_CONTROL_CHARS_RE, '').trim();
        if (!normalized) return true;

        try {
            const parsed = new URL(normalized, 'https://dummy.invalid/');
            // If the host is dummy.invalid, the URL was relative (no scheme)
            if (parsed.hostname === 'dummy.invalid') return true;
            return ALLOWED_PROTOCOLS.has(parsed.protocol);
        } catch {
            // Malformed URL -- reject
            return false;
        }
    }
}
